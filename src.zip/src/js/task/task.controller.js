angular.module('task')
  .controller('TaskCtrl', ['$scope', function($scope) {
    console.log('task')
  }]);
