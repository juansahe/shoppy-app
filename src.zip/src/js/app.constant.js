angular.module('Grimorum')
.constant("CONFIG", {
  "url": "",
  "API_URL" : ""
});
